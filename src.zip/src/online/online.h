#ifndef VOXELENGINE_ONLINE_H
#define VOXELENGINE_ONLINE_H

#include <string>

float myX;
float myY;
float myZ;

void tryConnectAsClient(std::wstring& IP, std::wstring& Name, std::wstring& Port);

#endif //VOXELENGINE_ONLINE_H




