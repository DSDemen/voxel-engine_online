#ifndef VOXELENGINE_COMMONFO_H
#define VOXELENGINE_COMMONFO_H



#pragma once

struct ClientInfo {
    int clientId;
    float x;
    float y;
    float z;
    float dir;
};

#endif //VOXELENGINE_COMMONFO_H
