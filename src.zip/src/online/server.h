#ifndef VOXELENGINE_SERVER_H
#define VOXELENGINE_SERVER_H


#include <string>

void tryConnectAsServer(std::wstring& IP, std::wstring& Name, std::wstring& Port);


#endif //VOXELENGINE_SERVER_H
