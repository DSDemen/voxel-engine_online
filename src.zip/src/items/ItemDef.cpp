#include "ItemDef.h"

ItemDef::ItemDef(std::string name) : name(name) {
}
